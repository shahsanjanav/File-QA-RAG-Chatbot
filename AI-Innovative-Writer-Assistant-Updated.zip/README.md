# 🤖 File QA RAG Chatbot App

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://your-app-name.streamlit.app)

A Streamlit-based Retrieval-Augmented Generation (RAG) chatbot that allows users to upload PDF files and ask context-aware questions using OpenAI GPT-3.5 and LangChain.

## 🔗 Live App
👉 [Launch App](https://your-app-name.streamlit.app)

## 🧠 Features
- Upload multiple PDF files
- Extracts content and embeds using OpenAI Embeddings
- Retrieves relevant context using FAISS
- Streams GPT-3.5 answers based on your questions

## 🚀 Tech Stack
- Streamlit
- LangChain
- OpenAI GPT-3.5 Turbo
- FAISS (vector similarity search)

## 📦 How to Run Locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## 🔐 API Key

To use the chatbot, you'll need an OpenAI API key.

### Option 1: Enter in the App (Recommended for Testing)
- Paste your API key directly into the **sidebar input field** when prompted.

### Option 2: Use Streamlit Secrets (Recommended for Deployment)
- Go to **Streamlit Cloud → [Your App] → Settings → Secrets**
- Add the following:
  ```
  OPENAI_API_KEY = "your-openai-api-key"
  ```

This ensures the key is securely loaded using `st.secrets["OPENAI_API_KEY"]`.

## 📄 License
MIT License © 2025 Sanjana Shah
